# PROJECT SPECIFICATION
# Cloud9 x JetBrains Hackathon - Automated Scouting Report Generator

**Version:** 1.0  
**Last Updated:** December 25, 2024  
**Developer:** Abdulmalik Alayande  
**Deadline:** February 3, 2026 @ 11:00am PST

---

## 🎯 PROJECT OVERVIEW

### What We're Building
An **automated VALORANT scouting report generator** that analyzes historical match data from GRID API to produce actionable pre-game insights for esports coaches and analysts.

### Problem Statement (Validated by Cloud9)
From conversations with **Halee Mason** (VP of Tech & Partnerships) and **Julien Cheng** (Software & Infrastructure Engineer):

**Current Pain Points:**
1. ❌ **Time-consuming manual VOD review** - Coaches spend hours weekly analyzing opponents
2. ❌ **Missing patterns** - Manual review misses statistical trends across multiple matches  
3. ❌ **Data consolidation** - Scattered data sources make pattern detection difficult
4. ❌ **Global meta tracking** - Hard to identify strategic trends from around the world

**Our Solution:**
✅ Automates opponent analysis using official GRID data  
✅ Detects patterns across 10-20 recent matches automatically  
✅ Consolidates all insights into one digestible report  
✅ Surfaces actionable "How to Win" counter-strategies

---

## 🏆 HACKATHON CATEGORY

**Category 2: Automated Scouting Report Generator**

**Prize:** $6,000 + Trip to GDC  
**Judging Criteria (Equal Weight):**
1. Technological Implementation (25%)
2. Design (25%)
3. Potential Impact (25%)
4. Quality of Idea (25%)

**Required Tools:**
- ✅ JetBrains IDEs (PyCharm for Python, IntelliJ for Java)
- ✅ Junie AI Agent (must document usage)
- ✅ GRID API (official esports data)

---

## 📋 SUBMISSION REQUIREMENTS

### Core Functionality (Must Have)

1. **Identify Team-wide Strategies**
   - Macro-level patterns (aggression, objective priorities)
   - Attack/defense tendencies by map
   - Default pistol round strategies
   - Economy management patterns

2. **Highlight Key Player Tendencies**
   - Individual player agent pools
   - Statistical outliers (K/D, combat score)
   - Player weaknesses in specific matchups
   - Role-specific patterns

3. **Summarize Compositions & Setups**
   - Most-played agent compositions
   - Composition win rates by map
   - Recent meta shifts

4. **Generate "How to Win" Insights** (Differentiator)
   - Data-backed counter-strategies
   - Exploitable weaknesses identified
   - Map veto recommendations
   - Agent ban/pick suggestions

### Demonstration Output (Example)

```
SCOUTING REPORT: Team Liquid (Last 10 Matches)

COMMON STRATEGIES:
- Attack: 70% of pistol rounds are 5-man B-Site rush (Ascent)
- Defense: Default 1-3-1 setup, rotating Sentinel to mid
- Win Rate: 70% overall (7-3 record)

PLAYER TENDENCIES:
- TenZ (Jett): 75% first-duel rate with Operator on A-main
- ScreaM: Plays Phoenix 80% of time, 1.45 K/D average

COMPOSITIONS:
- Most-played: Jett, Raze, Brimstone, Skye, Cypher (68% on Split)

HOW TO WIN:
✓ Ban Ascent (their best map, 80% win rate)
✓ Pick Icebox (their worst, 33% win rate)
✓ Expect Jett + Op on defense - counter with Raze/Jett
✓ Target ScreaM early - team struggles when he dies first
```

---

## 🏗️ TECHNICAL ARCHITECTURE

### System Type
**Hybrid Architecture:** Backend-heavy web application

**Why Hybrid?**
- Coaches want output, not tools (report-first design)
- Judges value production readiness over complexity
- Separates concerns: Java orchestrates, Python analyzes
- Clear deployment story with Docker

### Technology Stack

#### Backend - Python (Data Analysis Worker)
**Purpose:** GRID data ingestion, ETL, aggregation, report computation

**Technologies:**
- Python 3.11+
- `requests` - GRID API calls
- `pandas` - Data analysis (NO ML)
- `psycopg2` - PostgreSQL driver
- `pydantic` - Data validation and schemas
- `sqlalchemy` - ORM (optional)

**Why Python:**
- Fast iteration for data work
- Perfect for analyst-style aggregations
- Natural fit for GRID API parsing
- Judges recognize as "real" data engineering

#### Backend - Java Spring Boot (API Layer)
**Purpose:** Public API, orchestration, serving reports to frontend

**Technologies:**
- Java 17+
- Spring Boot 3.x
- Spring Data JPA
- PostgreSQL JDBC

**Why Java:**
- Enterprise credibility (Cloud9, professional teams)
- Clean architecture signals production-readiness
- Strong typing prevents errors
- Developer's core strength (2.5 years experience)

#### Database - PostgreSQL
**Purpose:** Source of truth for all data

**Tables:**
- `report_requests` - Job queue
- `matches` - Historical match data
- `scouting_reports` - Generated insights (JSONB for flexibility)

**Why PostgreSQL:**
- Coaches trust persistent historical data
- Enables "last 5 games", "map tendencies" queries
- JSONB columns for flexible report structure
- Judges value persistence over in-memory hacks

#### Frontend - React/Next.js
**Purpose:** Clean UI for report viewing

**Technologies:**
- React 18+
- Next.js 14+
- Tailwind CSS
- TypeScript (optional)

**Why Web UI:**
- Coaches need to scan quickly (not explore dashboards)
- No installation friction
- 3-minute demo must be instantly understandable
- Production teams can access from anywhere

#### Data Source - GRID API
**Only data source:** Official esports data directly from game servers

**APIs Used:**
- Central Data Feed (find teams, series)
- Stats Feed API (pre-aggregated statistics) ⭐ PRIMARY
- Series State API (individual match details)

**API Key:** `5MfhKhDoqnXQW6cKYbNea7znxf017Xgp9XbWXmCP`

---

## 🔄 DATA FLOW

### High-Level Architecture
```
┌──────────────────┐
│  React Frontend  │  (Displays reports)
└────────┬─────────┘
         │ HTTP
         ↓
┌────────────────────────────────┐
│  Java Spring Boot API          │
│  - POST /api/generate-report   │
│  - GET /api/report/{teamId}    │
└────────┬───────────────────────┘
         │ DB Write/Read
         ↓
┌────────────────────────────────┐
│      PostgreSQL                │
│  - report_requests (job queue) │
│  - matches (raw data)          │
│  - scouting_reports (results)  │
└────────┬───────────────────────┘
         │ Polls for jobs
         ↓
┌────────────────────────────────┐
│  Python Analysis Worker        │
│  1. Fetch GRID data            │
│  2. Run analysis               │
│  3. Write results to DB        │
└────────────────────────────────┘
```

### Communication Method
**Database as Contract** (Not HTTP between services)

**Why:**
- No fragile REST calls between Java/Python
- Survives restarts gracefully
- Easy to debug (inspect database)
- Clear audit trail
- Judges love boring, robust solutions

### Step-by-Step Flow
1. **User Request:** Frontend → `POST /api/generate-report` → Java API
2. **Job Creation:** Java writes to `report_requests` table (status: `pending`)
3. **Job Pickup:** Python worker polls `report_requests` for pending jobs
4. **Data Fetch:** Python calls GRID API (Stats Feed, Series State)
5. **Analysis:** Python aggregates patterns using pandas
6. **Results Storage:** Python writes to `scouting_reports`, updates request status to `completed`
7. **Report Retrieval:** Java reads from `scouting_reports`
8. **Display:** Frontend fetches via `GET /api/report/{teamId}`

---

## 📁 PROJECT STRUCTURE

### Python Analysis Worker (`grid-analysis/`)
```
grid-analysis/
│
├── venv/                       # Virtual environment
├── requirements.txt            # Python dependencies
├── .env                        # Environment variables (API keys)
├── .gitignore
│
├── config/
│   ├── environment.py          # Load .env
│   └── settings.py             # Configuration constants
│
├── clients/                    # GRID API clients
│   ├── grid/
│   │   ├── graphqlclient.py    # GraphQL HTTP client
│   │   └── exceptions.py       # Custom exceptions
│   ├── domain/
│   │   ├── teams.py            # Team queries
│   │   ├── series.py           # Series queries
│   │   └── stats.py            # Stats Feed queries
│   └── response/               # API response cache (dev)
│
├── models/                     # Pydantic data models
│   ├── team.py                 # Team, TeamStats
│   ├── match.py                # Match
│   └── report.py               # ScoutingReport, AgentPick, MapPerformance
│
├── ingestion/                  # Data fetching
│   ├── fetch_series.py         # Get match history
│   └── fetch_team_stats.py     # Get aggregated stats
│
├── transforms/                 # Analysis logic
│   ├── team_tendencies.py      # Team-level patterns
│   └── player_tendencies.py    # Player-level patterns
│
├── storage/                    # Database layer
│   ├── db.py                   # PostgreSQL connection
│   └── upsert.py               # Insert/update operations
│
├── jobs/                       # Orchestration
│   └── generate_report.py      # Main entry point
│
├── migrations/                 # Database schemas
│   └── 001_initial_schema.sql  # Create tables
│
└── tests/
    └── test_transforms.py
```

### Java Spring Boot API (`scouting-api/`) - TO BE CREATED
```
scouting-api/
│
├── src/main/java/com/cloud9/scoutingapi/
│   ├── controller/             # REST endpoints
│   │   └── ScoutingController.java
│   ├── service/                # Business logic
│   │   └── ReportService.java
│   ├── repository/             # Database access
│   │   ├── ReportRequestRepository.java
│   │   └── ScoutingReportRepository.java
│   ├── model/                  # JPA entities
│   │   ├── ReportRequest.java
│   │   └── ScoutingReport.java
│   └── ScoutingApiApplication.java
│
├── src/main/resources/
│   └── application.yml         # Spring configuration
│
└── pom.xml                     # Maven dependencies
```

### React Frontend (`scouting-ui/`) - TO BE CREATED
```
scouting-ui/
│
├── src/
│   ├── components/
│   │   ├── ReportView.tsx
│   │   └── TeamSearch.tsx
│   ├── pages/
│   │   └── index.tsx
│   └── services/
│       └── api.ts
│
├── package.json
└── next.config.js
```

### Deployment
```
docker-compose.yml              # Orchestrates all services
├── api/ (Java)
├── worker/ (Python)
├── db/ (PostgreSQL)
└── web/ (Next.js)
```

---

## 🗄️ DATABASE SCHEMA

### Tables

#### 1. `report_requests` (Job Queue)
```sql
CREATE TABLE report_requests (
    id SERIAL PRIMARY KEY,
    team_id VARCHAR(255) NOT NULL,
    team_name VARCHAR(255),
    time_window VARCHAR(50) DEFAULT 'LAST_3_MONTHS',
    status VARCHAR(50) DEFAULT 'pending',  -- pending, processing, completed, failed
    created_at TIMESTAMP DEFAULT NOW(),
    completed_at TIMESTAMP,
    error_message TEXT
);
```

#### 2. `matches` (Raw Match Data)
```sql
CREATE TABLE matches (
    id SERIAL PRIMARY KEY,
    series_id VARCHAR(255) UNIQUE NOT NULL,
    team_id VARCHAR(255) NOT NULL,
    team_name VARCHAR(255),
    opponent_id VARCHAR(255),
    opponent_name VARCHAR(255),
    map_name VARCHAR(100),
    won BOOLEAN,
    kills INT,
    deaths INT,
    assists INT,
    played_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);
```

#### 3. `scouting_reports` (Analysis Results)
```sql
CREATE TABLE scouting_reports (
    id SERIAL PRIMARY KEY,
    report_request_id INT REFERENCES report_requests(id),
    team_id VARCHAR(255) NOT NULL,
    team_name VARCHAR(255),
    
    -- Overview
    total_matches INT,
    total_games INT,
    win_rate DECIMAL(5,2),
    current_streak INT,
    
    -- Detailed analysis (JSONB)
    top_agents JSONB,           -- [{"agent": "Jett", "pick_rate": 0.80}]
    map_performance JSONB,       -- {"Ascent": {"wins": 4, "losses": 1}}
    player_stats JSONB,          -- [{"player": "TenZ", "kd": 1.45}]
    actionable_insights JSONB,   -- ["Ban Ascent", "Target TenZ early"]
    
    time_window VARCHAR(50),
    created_at TIMESTAMP DEFAULT NOW()
);
```

**Why JSONB:** Flexible schema for complex nested data, PostgreSQL indexes JSONB efficiently

---

## 🔌 API CONTRACTS

### Python → PostgreSQL
**Python writes to:**
- `matches` (after fetching from GRID)
- `scouting_reports` (after analysis)
- `report_requests` (updates status)

### Java → PostgreSQL
**Java reads from:**
- `scouting_reports` (serves to frontend)

**Java writes to:**
- `report_requests` (creates jobs)

### Frontend → Java API

#### POST `/api/generate-report`
**Request:**
```json
{
  "teamName": "Team Liquid",
  "timeWindow": "LAST_3_MONTHS"
}
```

**Response:**
```json
{
  "requestId": 123,
  "status": "pending",
  "message": "Report generation started"
}
```

#### GET `/api/report/{teamId}`
**Response:**
```json
{
  "teamId": "53625",
  "teamName": "Team Liquid",
  "totalMatches": 10,
  "winRate": 70.0,
  "topAgents": [
    {"agent": "Jett", "pickRate": 0.80}
  ],
  "mapPerformance": {
    "Ascent": {"wins": 4, "losses": 1, "winRate": 0.80}
  },
  "actionableInsights": [
    "Ban Ascent (80% win rate)",
    "Pick Icebox (33% win rate)"
  ]
}
```

---

## ⚙️ ENVIRONMENT VARIABLES

### `.env` File (Python)
```bash
# GRID API
GRID_API_KEY=5MfhKhDoqnXQW6cKYbNea7znxf017Xgp9XbWXmCP
GRID_QUERY_API=https://api-op.grid.gg/central-data/graphql
GRID_STATS_API=https://api-op.grid.gg/statistics-feed/graphql
GRID_SERIES_STATE_API=https://api-op.grid.gg/live-data-feed/series-state/graphql

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/grid_scouting
```

### `application.yml` (Java)
```yaml
spring:
  datasource:
    url: jdbc:postgresql://localhost:5432/grid_scouting
    username: user
    password: password
  jpa:
    hibernate:
      ddl-auto: validate
```

---

## 🚀 DEPLOYMENT STRATEGY

### Local Development
```bash
# Start database
docker-compose up -d db

# Run Python worker
cd grid-analysis
python jobs/report_generator.py

# Run Java API
cd scouting-api
./mvnw spring-boot:run

# Run React frontend
cd scouting-ui
npm run dev
```

### Production (Docker Compose)
```yaml
version: '3.8'
services:
  db:
    image: postgres:15
    environment:
      POSTGRES_DB: grid_scouting
      POSTGRES_USER: user
      POSTGRES_PASSWORD: password
    ports:
      - "5432:5432"
  
  api:
    build: ./scouting-api
    ports:
      - "8080:8080"
    depends_on:
      - db
  
  worker:
    build: ./grid-analysis
    depends_on:
      - db
  
  web:
    build: ./scouting-ui
    ports:
      - "3000:3000"
    depends_on:
      - api
```

**One command:** `docker-compose up`

---

## 🎯 SUCCESS METRICS

### Minimum Viable Product (MVP)
- [ ] Accept team name input
- [ ] Fetch last 10 matches from GRID
- [ ] Generate basic statistics (win rate, top agents, map performance)
- [ ] Display report in clean UI
- [ ] Complete end-to-end flow (Frontend → Java → Python → DB → Java → Frontend)

### Competitive Submission
- [ ] "How to Win" actionable insights
- [ ] Fast generation (<30 seconds)
- [ ] Professional UI design
- [ ] Multiple team comparison
- [ ] Docker deployment working
- [ ] Documented Junie usage

### Winning Submission
- [ ] Historical trend analysis
- [ ] Visual data presentation (charts)
- [ ] PDF export
- [ ] Surprising insights coaches wouldn't find manually
- [ ] Testimonial/feedback from a coach

---

## 📝 DEVELOPMENT PROGRESS

### Completed ✅
- [x] Database schema designed (`001_initial_schema.sql`)
- [x] Python project structure
- [x] GRID API clients (teams, series)
- [x] Pydantic models (Team, Match, Report)
- [x] GraphQL client with error handling
- [x] Configuration management

### In Progress 🔄
- [ ] `db.py` - PostgreSQL connection implementation
- [ ] Stats Feed API client (`stats.py`)
- [ ] Analysis transforms (`team_tendencies.py`, `player_tendencies.py`)

### Not Started ❌
- [ ] Java Spring Boot API
- [ ] React frontend
- [ ] Docker Compose setup
- [ ] Report generation job
- [ ] End-to-end testing

---

## 📚 KEY REFERENCES

### Documentation
- [GRID API Reference Guide](./GRID_REFERENCE_GUIDE.md)
- [Project Architecture](./ARCHITECTURE.md)
- [Data Flow](./DATA_FLOW.md)
- [Coding Guidelines](./CODING_GUIDELINES.md)

### External Resources
- **GRID Portal:** http://portal.grid.gg
- **Hackathon Page:** https://cloud9.devpost.com/
- **Cloud9 Discord:** "Sky's the Limit" channels
- **Office Hours:** Julien Cheng, January 2nd

### GitHub Gists (API Docs)
- [API Documentation](https://gist.github.com/AbdulmalikAlayande/55dbcd6b4ead9244c31d02fb217d5994)
- [Stats Feed API](https://gist.github.com/AbdulmalikAlayande/6214e5bdb14c51814e9cac24471c6cf5)
- [Series State API](https://gist.github.com/AbdulmalikAlayande/35dbae9f8e338dc86e0a2244adbe2a55)
- [Query & Mutations](https://gist.github.com/AbdulmalikAlayande/94eb6af3874a9531d688e962ea996a84)

---

## ⚠️ CRITICAL CONSTRAINTS

### What We MUST Use
✅ JetBrains IDEs (PyCharm, IntelliJ)  
✅ Junie AI agent  
✅ GRID API (official data only)  
✅ OSI open-source license  
✅ Public GitHub repository  

### What We MUST NOT Use
❌ Machine Learning models  
❌ Both LoL and VALORANT (VALORANT only)  
❌ Web scraping  
❌ Unofficial data sources  
❌ Native mobile/desktop apps  

### Time Constraints
**Deadline:** February 3, 2026 @ 11:00am PST  
**Days Remaining:** ~39 days from December 25, 2024

---

## 🎬 DEMO VIDEO REQUIREMENTS

### Must Show (3 minutes max)
1. **Problem** (15 sec): "Coaches spend hours manually reviewing opponents"
2. **Solution** (20 sec): "Our tool automates scouting report generation"
3. **Live Demo** (90 sec):
   - Input opponent name
   - Show processing
   - Display generated report
   - Highlight key insights
4. **Technical** (30 sec): "Built with JetBrains/Junie, uses GRID data"
5. **Impact** (15 sec): "Saves X hours, provides actionable strategies"

### Production Checklist
- [ ] Clear audio
- [ ] Clean UI (no debug messages)
- [ ] Real data (actual teams)
- [ ] Smooth demo (pre-tested)
- [ ] Show code briefly
- [ ] Under 3 minutes

---

## 🏅 WINNING STRATEGY

### Tech Implementation (25%)
**Win with:** Clean architecture, proper separation of concerns, Docker deployment

### Design (25%)
**Win with:** Report-first UI (not dashboards), coach-friendly layout, fast generation

### Potential Impact (25%)
**Win with:** Solves real Cloud9 pain points (Halee/Julien validated), production-ready

### Quality of Idea (25%)
**Win with:** "How to Win" insights (not just stats), matches organizer examples exactly

---

**END OF SPECIFICATION**