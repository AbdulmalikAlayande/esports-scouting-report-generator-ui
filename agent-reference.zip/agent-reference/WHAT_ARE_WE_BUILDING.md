# **COMPLETE PICTURE: What We're Building**

## **The Tool: VALORANT Automated Scouting Report Generator**

**Simple Version:**
- **Input:** Opponent team name (e.g., "Team Liquid")
- **Process:** Fetch their recent matches from GRID → Analyze patterns → Generate insights
- **Output:** Professional scouting report with actionable counter-strategies

---

## **What I Now Understand from ALL the Docs**

### **1. Central Data Feed (Static Data)**
**What:** Team names, player names, tournaments, series schedules  
**API:** GraphQL  
**URL:** `https://api-op.grid.gg/central-data/graphql`  
**Used for:** Finding team IDs, getting series lists, finding match schedules

**Key queries we'll use:**
- `teams` - Find team by name, get team ID
- `allSeries` - Get recent matches for a team
- `players` - Get player info for a team

---

### **2. Series State API (Match Data)**
**What:** Final state of completed matches (kills, deaths, agents picked, rounds won, etc.)  
**API:** GraphQL  
**URL:** `https://api-op.grid.gg/live-data-feed/series-state/graphql`  
**Used for:** Getting detailed match data after games are finished

**Key data we'll extract:**
- Player stats (kills, deaths, K/D ratio, agents played)
- Team stats (rounds won, sites attacked, win rates)
- Match outcomes

---

### **3. Stats Feed API (Aggregated Statistics) ⭐ THIS IS OUR MAIN ONE**
**What:** Pre-aggregated statistics across multiple matches  
**API:** GraphQL  
**URL:** `https://api-op.grid.gg/statistics-feed/graphql`  
**Used for:** Getting sum/min/max/avg across many games (PERFECT for scouting reports!)

**Key queries:**
- `teamStatistics` - Team performance across multiple series
- `playerStatistics` - Player performance across multiple series
- `teamGameStatistics` - Team performance across multiple games

**What it gives us automatically:**
- `sum` - Total kills across all matches
- `min` - Worst performance
- `max` - Best performance
- `avg` - Average per match
- `percentage` - Win rates
- `streak` - Win/loss streaks

**This is GOLD because we don't have to manually calculate anything!**

---

### **4. Series Events API (Real-time WebSocket)**
**What:** Live event stream during matches  
**API:** WebSocket  
**Used for:** Real-time analysis (NOT for MVP - historical data only)

---

### **5. File Download API**
**What:** Download complete match data as files  
**API:** REST  
**Used for:** Getting full match history if needed (backup option)

---

## **Our Implementation Strategy**

### **Phase 1: Get Team Data (Central Data Feed)**
#### Query 1: Find team by name
```text
query {
  teams(filter: { name: { equals: "Team Liquid" }}) {
    edges {
      node {
        id
        name
      }
    }
  }
}
```
#### Query 2: Get their recent series
```graphql
query {
  allSeries(filter: {
    teamIds: { in: ["team-id-here"] }
    startTimeScheduled: { gte: "2024-11-01", lte: "2025-01-01" }
  }) {
    edges {
      node {
        id
        teams { baseInfo { name }}
      }
    }
  }
}
```

### **Phase 2: Get Aggregated Stats (Stats Feed API) ⭐**
#### Query: Get team statistics for last 3 months
```graphql
query {
  teamStatistics(
    teamId: "team-id-here"
    filter: { timeWindow: LAST_3_MONTHS }
  ) {
    series { count }  # Number of matches
    game {
      kills { sum, min, max, avg }
      deaths { sum, min, max, avg }
      wins { 
        count
        percentage
        streak { max, current }
      }
    }
  }
}
```
#### Query: Get player statistics
```graphql
query {
  playerStatistics(
    playerId: "player-id-here"
    filter: { timeWindow: LAST_3_MONTHS }
  ) {
    game {
      kills { avg }
      deaths { avg }
    }
  }
}
```

### **Phase 3: Get Detailed Match Data (Series State API - if needed)**
#### Query: Get specific match details
```graphql
query {
  series(id: "series-id-here") {
    games {
      teams {
        name
        players {
          nickname
          kills
          deaths
          character { name }  # Agent played
        }
      }
    }
  }
}
```

---

## **The Report We'll Generate**

```text
=== TEAM LIQUID SCOUTING REPORT ===
(Last 10 Matches)

📊 OVERVIEW:
- Record: 7-3 (70% win rate)
- Most Played Map: Ascent (5 matches, 80% win rate)
- Current Form: W-W-L-W-W (2 game win streak)

🎯 AGENT COMPOSITION:
Most Picked Agents:
1. Jett - 80% pick rate (8/10 matches)
2. KAY/O - 70% pick rate (7/10 matches)
3. Fade - 60% pick rate (6/10 matches)

Signature Lineup: Jett, KAY/O, Fade, Viper, Omen (4/7 wins)

🗺️ MAP PERFORMANCE:
Strong Maps:
- Ascent: 80% win rate (4-1)
- Haven: 66% win rate (4-2)

Weak Maps:
- Icebox: 33% win rate (1-2)
- Breeze: Avoided (0 matches)

👥 KEY PLAYERS:
TenZ (Jett):
- K/D: 1.45 (avg 18 kills, 12 deaths per game)
- Combat Score: 285 avg
- First Blood: 35% of rounds

ScreaM (Phoenix/KAY/O):
- K/D: 1.32 (avg 16 kills, 12 deaths)
- Combat Score: 268 avg
- Clutch Rate: 28%

⚡ HOW TO WIN:
1. MAP VETO: Ban Ascent (their best), pick Icebox (their worst)
2. AGENT COUNTERS: Prepare anti-Jett utility, expect Op usage
3. EARLY AGGRESSION: Target ScreaM first - team struggles when he dies early
4. SITE PREFERENCE: They attack B-site 65% on pistol rounds - stack B defense
```

---

## **Why This Works with Your Skills**

✅ **80% Backend Work (Your Strength):**
- GraphQL API calls
- JSON data parsing
- Database storage (PostgreSQL)
- Data aggregation
- Report generation

✅ **20% Analysis (Just Using Stats Feed):**
- Stats Feed does all the math (sum, avg, max, min)
- You just query it and format the results
- No ML, no complex algorithms

✅ **No Game Knowledge Required:**
- The data tells you what's important
- Stats like "80% win rate on Ascent" are self-explanatory
- You're surfacing patterns, not interpreting strategy

---

## **Next Step: Write Your First Query**

Now that I've read ALL the docs, I can help you write actual working code.

**Tell me:** Are you ready to write your first GRID API call, or do you have questions about what I just explained?