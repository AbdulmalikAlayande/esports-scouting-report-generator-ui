## WAYS USERS CAN USE THE SYSTEM AND ALL THE WAYS USERS CAN PROMPT THE SYSTEM

1. Generate a full scouting report for [Opponent Team Name] based on their last [X] matches.
2. How did Team Liquid perform on Ascent specifically? or What are their stats on this particular map?
3. Game Rounds (can be much more than one type of prompt for this), meaning prompts can come in multiple formats for this "Game Round"
4. Tournament prompt, as in the X tournament, based on their performance in this tournament.
5. Monthly or Yearly prompt, based on their performance in this time period. X months, X years.
6. Other prompts as needed.

### **1. Full Scouting Report (Core)**
#### Ways Users can prompt
```text
User: "Generate scouting report for Team Liquid"
User: "Scout Sentinels based on last 10 matches"
User: "How do we beat Cloud9?"
```
#### System Interpretation:
```text
→ Fetches team stats
→ Analyzes patterns
→ Generates full report with "How to Win"
```

### **2. Map-Specific Analysis**
#### Ways Users can prompt
```text
User: "How does Team Liquid perform on Ascent?"
User: "What's Sentinels' win rate on Bind?"
User: "Best map to pick against Cloud9?"
```
#### System Interpretation:
```text
→ Uses teamGameStatistics filtered by map
→ Returns map-specific insights
→ Suggests map veto strategy
```

### **3. Time Period Analysis**
#### Ways Users can prompt
```text
User: "How has Team Liquid performed in the last month?"
User: "Show me Cloud9's stats from last year"
User: "Recent form of Sentinels"
```
#### System Interpretation:
```text
→ Adjusts time_window filter
→ Shows trend (improving/declining)
→ Highlights recent changes
```

### **4. Tournament-Specific**
#### Ways Users can prompt
```text
User: "How did Team Liquid do in VCT Champions?"
User: "Cloud9's performance in Masters"
```
#### System Interpretation:
```text
→ Filters by tournament ID
→ Tournament-specific stats
→ Opponent matchups in that tournament
```

### **5. Player-Specific**
#### Ways Users can prompt
```text
User: "How's TenZ performing lately?"
User: "Who's Team Liquid's best player?"
User: "Compare TenZ vs Aspas"
```

#### System Interpretation:
```text
→ playerStatistics query
→ Individual player breakdown
→ Impact analysis
```

### **6. Composition Analysis** ⭐
#### Ways Users can prompt
```text
User: "What comps does Team Liquid run?"
User: "Most successful agent lineup for Cloud9?"
```
#### System Interpretation:
```text
→ Analyzes 5-agent compositions
→ Win rates per comp
→ Suggests counter-comps
```

### **7. Head-to-Head** ⭐
#### Ways Users can prompt
```
User: "Team Liquid vs Sentinels history"
User: "How does Cloud9 match up against LOUD?"
```
#### System Interpretation:
```text
→ Filters matches between two teams
→ Historical win rates
→ Style clash analysis
```

### **8. Weakness Detection** ⭐ (THE DIFFERENTIATOR)
#### Ways Users can prompt
```text
User: "What are Team Liquid's weaknesses?"
User: "How to exploit Cloud9?"
``` 

#### System Interpretation:
```text
→ Analyzes worst maps
→ Identifies vulnerable players
→ Finds pattern weaknesses
→ Generates attack plan
```

## **9. Live Decision Making & In-Game Context - For context aware suggestions**
### Ways Users can prompt
```text
User: Okay, we just lost mid-lane tower at 15 minutes, what's our best counter-strategy?
User: 
```

#### System Interpretation:
```text

```

## **10. Identifying "Tells" or Specific "Exploits"**

Coaches want to know the exact moment an opponent breaks their pattern. 
The current WeaknessDetectionAnalysisTool is general, this is specific.
### Ways Users can prompt
```text

```

#### System Interpretation:
```text

```



## ALTERNATIVES TO USING MCP or NLP STYLE TO PARSE USER PROMPTS 
### Instead of Using MCP

#### jobs/prompt_router.py
```
class ScoutingPromptRouter:
    """
    Parse user prompts and route to appropriate analysis
    """
    
    def process_prompt(self, prompt: str) -> dict:
        """
        Convert natural language to structured query
        """
        prompt_lower = prompt.lower()
        
        # Pattern 1: Full scouting report
        if "scouting report" in prompt_lower or "generate report" in prompt_lower:
            return self._handle_full_report(prompt)
        
        # Pattern 2: Map-specific query
        if any(map_name in prompt_lower for map_name in ["ascent", "bind", "haven", "split"]):
            return self._handle_map_query(prompt)
        
        # Pattern 3: Time period query
        if any(word in prompt_lower for word in ["last", "recent", "past"]):
            return self._handle_time_period(prompt)
        
        # Pattern 4: Tournament-specific
        if "tournament" in prompt_lower or "championship" in prompt_lower:
            return self._handle_tournament_query(prompt)
        
        # Pattern 5: Player-specific
        if "player" in prompt_lower or any(role in prompt_lower for role in ["duelist", "sentinel"]):
            return self._handle_player_query(prompt)
        
        # Default: Full report
        return self._handle_full_report(prompt)
    
    def _handle_full_report(self, prompt: str):
        team_name = self._extract_team_name(prompt)
        match_count = self._extract_number(prompt, default=10)
        
        return {
            "type": "full_report",
            "team_name": team_name,
            "match_count": match_count,
            "time_window": "LAST_3_MONTHS"
        }
    
    def _handle_map_query(self, prompt: str):
        team_name = self._extract_team_name(prompt)
        map_name = self._extract_map_name(prompt)
        
        return {
            "type": "map_analysis",
            "team_name": team_name,
            "map_name": map_name
        }
    
    # More handlers...
```

### 1. Simple pattern matching
```aiignore
def route_prompt(prompt):
    if "scouting report" in prompt:
        return generate_full_report(extract_team(prompt))
    elif "map" in prompt:
        return analyze_map(extract_team(prompt), extract_map(prompt))
    # ... basic routing
```
### 2. Use regex and simple NLP
```aiignore
# Use regex + simple NLP
import re

def extract_team(prompt):
    # "Generate report for Team Liquid"
    match = re.search(r'(?:for|about|on)\s+(.+?)(?:\s+based|\s+in|$)', prompt)
    return match.group(1) if match else None

def extract_time_window(prompt):
    if "last month" in prompt: return "LAST_1_MONTH"
    if "last 3 months" in prompt: return "LAST_3_MONTHS"
    # ...
```

### 3. Context Memory (If Time)
#### # Remember previous context
```
class ConversationContext:
    def __init__(self):
        self.current_team = None
        self.current_map = None
    
    def process(self, prompt):
        if "their" in prompt or "they" in prompt:
            # Use self.current_team
            pass
```

#### **Example:**
```text
User: "Scout Team Liquid"
Bot: [Generates report for Team Liquid]
User: "How do they perform on Ascent?" ← Uses context (Team Liquid)
Bot: [Shows Team Liquid on Ascent]
```