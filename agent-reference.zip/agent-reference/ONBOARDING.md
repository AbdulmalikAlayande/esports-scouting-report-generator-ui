<artifact identifier="project-bible" type="text/markdown" title="Project Bible: Elite Scouting Report System">

# **PROJECT BIBLE: Elite Scouting Report System**
**Version 1.0 | Onboarding Document | Read Time: 20 Minutes**

---

## **TABLE OF CONTENTS**

1. [The Mission: Why We're Building This](#the-mission)
2. [What "Elite" Looks Like (Example)](#what-elite-looks-like)
3. [System Architecture Overview](#system-architecture)
4. [The Insight Object: Our Core Innovation](#the-insight-object)
5. [The Priority Scoring System](#priority-scoring)
6. [The Three-Layer Report Structure](#three-layer-report)
7. [Technology Stack](#technology-stack)
8. [Current State & What We're Building](#current-state)
9. [Key Architectural Decisions](#architectural-decisions)
10. [Success Metrics](#success-metrics)

---

## **THE MISSION: Why We're Building This** {#the-mission}

### **The Problem**
Professional esports coaches spend **10+ hours per week** manually analyzing opponents:
- Watching VODs frame-by-frame
- Taking notes in spreadsheets
- Manually identifying patterns
- Missing statistical trends that only emerge across 20+ matches

**Current tools just dump stats** - no actionability, no "how to win", no drill prescriptions.

### **Our Solution**
We're building **decision support infrastructure**, not just a report generator.

**What makes us different:**
- ✅ **15-second flash cards** (top 3-5 actionable insights)
- ✅ **Velocity/trend analysis** ("PlayerX dropped from 1.11 to 0.96 K/D in 2 weeks")
- ✅ **Counter-risk modeling** ("If you ban Icebox, they'll pick Ascent - here's the mitigation")
- ✅ **Drill prescriptions** ("Practice B-site retake defense for 15 minutes")
- ✅ **Meta awareness** ("This comp is 2.5x more popular for them than global average")

### **The Stakes**
- **3,000 developers** competing in this hackathon
- **$6,000 prize** + trip to GDC
- **Judges are Cloud9's actual coaches** - they want production-ready tools
- **We're currently 70% done** - ingestion works, database works, structure exists
- **We need to nail the insight generation layer in 10 days**

---

## **WHAT "ELITE" LOOKS LIKE (Example)** {#what-elite-looks-like}

### **Real Professional Analysis: VCT 2025 Grand Finals**

Here's an excerpt from a real professional scouting report (G2 vs NRG):

```
EXECUTIVE SUMMARY: TOP 5 RECURRING MISTAKES

| Rank | Mistake Pattern              | Primary Offender | Impact        | Rounds Lost |
|------|------------------------------|------------------|---------------|-------------|
| 1    | Opener Death → Zero Value    | mada (NRG)       | 85% loss rate | 17 rounds   |
| 2    | Zero-Kill Deaths (instant)   | mada (56%)       | No trade     | 38+ instances|
| 3    | Failed Clutch Execution      | skuba (2/3 lost) | Winnable     | 3 clutches  |
| 4    | Streaking Collapse           | NRG (9-round)    | Full map     | Bind lost   |
| 5    | Uncontested First Deaths     | NRG defense      | No trades    | 30+ rounds  |

ACTIONABLE COUNTER-STRATEGIES:
✓ Exploit mada's entry protocol - he dies first 20 times with 85% team loss rate
🎯 Target mada early rounds - NRG loses 7/7 when he gets first death on Bind
⚔️ Apply post-plant pressure - they only convert 49% of spike plants
⚠️ Force early pressure - mada takes first duel without utility support 85% of time
```

**THIS IS OUR QUALITY BAR.**

Notice:
- Specific numbers (85%, 17 rounds, 7/7)
- Tactical prescriptions ("Exploit entry protocol", "Apply post-plant pressure")
- Player-specific targeting ("mada", "skuba")
- Round-level granularity ("Bind R13-R21")

---

## **SYSTEM ARCHITECTURE OVERVIEW** {#system-architecture}

### **The Full Data Flow**

```
┌─────────────────────────────────────────────────────────────────┐
│                       USER INTERFACE                            │
│  (React Frontend - Displays reports, takes natural language    │
│   prompts like "Generate scouting report for Team Liquid")     │
└────────────────────────────┬────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│                     JAVA SPRING BOOT API                        │
│  - POST /api/report-request (creates job in database)          │
│  - GET /api/report/{id} (retrieves completed report)           │
└────────────────────────────┬────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│                    POSTGRESQL DATABASE                          │
│  Tables:                                                        │
│  - report_requests (job queue with user_prompt column)         │
│  - scouting_reports (generated reports)                        │
└────────────────────────────┬────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│                  PYTHON ANALYSIS WORKER                         │
│  File: jobs/report_generator.py                                │
│  - Polls report_requests for pending jobs every 5 seconds      │
│  - Picks up user_prompt and routes to appropriate handler      │
└────────────────────────────┬────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│               GENERAL PROMPT ROUTER (LLM-POWERED)               │
│  File: jobs/prompt_router.py                                   │
│  - Uses Gemini 2.5 Flash to understand natural language        │
│  - Routes to appropriate tool/handler function                 │
│  - Tools: ScoutingReportTool, MapAnalysisTool, etc.           │
└────────────────────────────┬────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│                     HANDLER FUNCTIONS                           │
│  File: jobs/handler_functions.py                               │
│  - handle_generate_full_scouting_report(team_name, ...)       │
│  - handle_generate_map_analysis(team_name, map_name, ...)     │
│  - [12 total handlers for different analysis types]            │
└───────────┬──────────────────────────────────┬──────────────────┘
            ↓                                  ↓
┌───────────────────────────┐    ┌────────────────────────────────┐
│   INGESTION LAYER         │    │     TRANSFORM LAYER            │
│   (Fetch from GRID APIs)  │    │     (Analyze the data)         │
├───────────────────────────┤    ├────────────────────────────────┤
│ • fetch_teams.py          │    │ • team_analysis.py             │
│ • fetch_stats.py          │    │ • player_analysis.py           │
│ • fetch_series.py         │    │ • map_analysis.py              │
│ • fetch_match_details.py  │    │ • composition_analysis.py      │
│                           │    │ • weakness_detection.py        │
│ Returns: Normalized dicts │    │ • velocity_engine.py (NEW)     │
│ with team stats, player   │    │ • counter_risk_modeler.py (NEW)│
│ stats, match history      │    │ • drill_generator.py (NEW)     │
└───────────┬───────────────┘    │ • meta_analyzer.py (NEW)       │
            │                    └────────────┬───────────────────┘
            └────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│                  INSIGHT GENERATOR (THE BRAIN)                  │
│  File: transforms/insight_generator.py                          │
│  - Takes raw analysis outputs                                   │
│  - Generates Insight Objects                                    │
│  - Scores insights by priority (impact × confidence)            │
│  - Returns top 5-10 insights + full breakdown                   │
└────────────────────────────┬────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│                     REPORT RENDERER                             │
│  File: transforms/report_renderer.py (NEW)                     │
│  - Formats insights into 3-layer structure                      │
│  - Flash Card (15s) → Tactical (5min) → Appendix (60min)       │
│  - Outputs: JSON, Markdown, PDF                                │
└────────────────────────────┬────────────────────────────────────┘
                             ↓
┌─────────────────────────────────────────────────────────────────┐
│                    BACK TO DATABASE                             │
│  - Insert into scouting_reports table                          │
│  - Update report_requests status to 'completed'                │
└─────────────────────────────────────────────────────────────────┘
```

---

## **THE INSIGHT OBJECT: Our Core Innovation** {#the-insight-object}

### **What is an Insight Object?**

An Insight Object is a **structured data representation** of a single actionable recommendation.

Instead of this (plain text):
```
"NRG struggles on Icebox with a 30% win rate, so you should ban it."
```

We use this (structured data):
```python
{
    # Core Fields (JetBrains AI Foundation)
    "title": "Permaban Candidate: Icebox",
    "recommendation": "Ban Icebox in map veto",
    "reason": "30% win rate over 15 games",
    "confidence": 0.89,  # High sample size, stable trend
    "impact": 0.85,      # Large win rate gap
    "evidence": [
        "3 wins, 12 losses on Icebox (30% WR)",
        "Attack side: 25% WR (worst of all maps)",
        "Defense side: 35% WR (below team avg of 55%)"
    ],
    "scope": "map_veto_macro",
    
    # Temporal Context (Google AI's "Velocity" Concept)
    "trend": "declining",        # Getting worse over time
    "velocity": -0.12,           # Dropped 12% in last month
    "forecast": "worsening",     # Predicted to continue declining
    
    # Risk Modeling (Critical Addition)
    "counter_risk": "Forces them to Ascent (their 2nd best at 75% WR)",
    "mitigation": "If they pick Ascent, run anti-Jett comp with KAY/O",
    
    # Actionability (Critical Addition)
    "drill_prescription": {
        "name": "Icebox B-Site Attack Practice",
        "duration": "20 minutes",
        "setup": "5v5 - Attackers spawn A, must execute B",
        "focus": "Coordinated utility usage, post-plant positions"
    },
    
    # Meta Awareness (Critical Addition)
    "global_meta": {
        "popularity": 0.22,  # 22% global pick rate
        "counter_known": True,  # Known how to counter
        "source": "VCT Champions 2025 meta report"
    },
    "local_edge": "They pick Icebox 8% (2.7x BELOW global avg)"
}
```

### **Why This Matters**

**With plain text:**
- Can't sort by priority
- Can't reuse across formats
- Can't track if advice worked
- Hard to build trust (no evidence)

**With Insight Objects:**
- ✅ Sort by `priority_score` (top 5 to user, rest to appendix)
- ✅ Render to: UI cards, PDF, plain text, JSON API
- ✅ Track outcomes ("We said ban Icebox, they did, they won")
- ✅ Build trust (evidence bullets, confidence scores)

---

## **THE PRIORITY SCORING SYSTEM** {#priority-scoring}

### **The Formula**

```python
priority_score = impact × confidence × freshness × sample_quality
```

**Range:** 0.0 (ignore) to 1.0 (critical)

### **The Factors**

#### **1. Impact (0-1): How much does this change win probability?**

Calculated from the **magnitude of the statistical gap**:

```python
def calculate_impact(stat_value, baseline):
    """
    Examples:
    - Map WR: 30% vs baseline 50% → gap = 20% → impact = 0.80
    - Player K/D: 0.8 vs baseline 1.0 → gap = 0.2 → impact = 0.60
    - Economy: $8500 avg vs baseline $9000 → gap = $500 → impact = 0.30
    """
    gap = abs(stat_value - baseline)
    max_gap = baseline  # Normalize by baseline
    return min(gap / max_gap, 1.0)
```

**Example:**
- Icebox WR: 30% (baseline 50%) → gap = 20pp → **impact = 0.80**
- PlayerX K/D: 0.96 (baseline 1.05) → gap = 0.09 → **impact = 0.43**

---

#### **2. Confidence (0-1): How sure are we?**

Based on **sample size and variance**:

```python
def calculate_confidence(sample_size, variance):
    """
    Examples:
    - 20 games, low variance (stable) → confidence = 0.95
    - 5 games, high variance (volatile) → confidence = 0.40
    - 50 games, moderate variance → confidence = 0.85
    """
    # Wilson score interval (statistical method)
    z = 1.96  # 95% confidence level
    n = sample_size
    
    if n < 5:
        return 0.3  # Too small
    elif n < 10:
        return 0.5
    elif n < 20:
        return 0.7
    else:
        return min(0.95, 0.7 + (n - 20) * 0.01)
```

**Example:**
- Icebox: 15 games → **confidence = 0.75**
- PlayerX K/D: 3 games → **confidence = 0.30**

---

#### **3. Freshness (0-1): How recent is the data?**

Exponential decay from the most recent match:

```python
def calculate_freshness(days_since_last_match):
    """
    Examples:
    - Last match: yesterday → freshness = 1.00
    - Last match: 1 week ago → freshness = 0.85
    - Last match: 1 month ago → freshness = 0.50
    - Last match: 3 months ago → freshness = 0.20
    """
    decay_rate = 0.02  # 2% per day
    return max(0.2, 1.0 - (days_since_last_match * decay_rate))
```

**Example:**
- Last match 5 days ago → **freshness = 0.90**
- Last match 30 days ago → **freshness = 0.40**

---

#### **4. Sample Quality (0-1): Is the trend stable?**

Based on **consistency across time periods**:

```python
def calculate_sample_quality(values):
    """
    Examples:
    - Stable: [0.30, 0.32, 0.29, 0.31] → low variance → quality = 0.95
    - Volatile: [0.50, 0.10, 0.60, 0.25] → high variance → quality = 0.40
    """
    std_dev = standard_deviation(values)
    mean = average(values)
    coefficient_of_variation = std_dev / mean
    
    if coefficient_of_variation < 0.1:
        return 0.95  # Very stable
    elif coefficient_of_variation < 0.3:
        return 0.70  # Moderately stable
    else:
        return 0.40  # Volatile
```

**Example:**
- Icebox WR: [0.28, 0.31, 0.30, 0.29] → **sample_quality = 0.95**
- PlayerX K/D: [1.2, 0.7, 1.1, 0.8] → **sample_quality = 0.45**

---

### **Example: Full Priority Score Calculation**

**Insight A: "Ban Icebox"**
```python
impact = 0.80        # 30% WR vs 50% baseline
confidence = 0.75    # 15 games
freshness = 0.90     # Last match 5 days ago
sample_quality = 0.95  # Stable trend

priority_score = 0.80 × 0.75 × 0.90 × 0.95 = 0.513
```

**Insight B: "Target PlayerX"**
```python
impact = 0.43        # 0.96 K/D vs 1.05 baseline
confidence = 0.30    # Only 3 games
freshness = 0.90     # Recent
sample_quality = 0.45  # Volatile

priority_score = 0.43 × 0.30 × 0.90 × 0.45 = 0.052
```

**Result:** Insight A (0.513) ranks higher than Insight B (0.052).

**Flash Card shows:** Top 5 insights (typically score > 0.40)

---

## **THE THREE-LAYER REPORT STRUCTURE** {#three-layer-report}

### **Layer 1: FLASH CARD (15 seconds)**

**Purpose:** Immediate actionability - coaches scan this pre-game

**Content:** Top 3-5 insights (priority score > 0.40)

**Format:**
```
┌─────────────────────────────────────────────────────────┐
│  🎯 HOW TO BEAT NRG (Flash Summary)                     │
├─────────────────────────────────────────────────────────┤
│  ✓ BAN Icebox (30% WR, declining trend)                │
│  🎯 TARGET mada early (85% team loss rate when FD)      │
│  ⚔️ EXPLOIT post-plant (21% conversion rate)            │
│  ⚠️ WATCH Player312 (1.17 K/D, 15 kills/game)          │
│  💰 FORCE eco rounds (conservative economy)             │
└─────────────────────────────────────────────────────────┘
```

**User Experience:**
- Coach glances at this 5 minutes before match
- Gets instant game plan
- Can click any insight for details

---

### **Layer 2: TACTICAL BREAKDOWN (5 minutes)**

**Purpose:** Pre-game prep - coaches/analysts read this 1 hour before match

**Content:** Insights grouped by tactical category

**Format:**
```
┌─────────────────────────────────────────────────────────┐
│  📊 TACTICAL BREAKDOWN                                   │
└─────────────────────────────────────────────────────────┘

╔═══════════════════════════════════════════════════════════╗
║  MACRO ANALYSIS (Pre-Game Decisions)                     ║
╚═══════════════════════════════════════════════════════════╝

Map Vetoes
──────────
✓ BAN Icebox
  • Reason: 30% win rate over 15 games (20pp below baseline)
  • Trend: Declining (dropped from 40% to 30% in last month)
  • Evidence:
    - Attack side: 25% WR (worst of all maps)
    - Defense side: 35% WR (below team avg)
    - Lost 9 of last 12 games on this map
  • Counter-Risk: Forces them to Ascent (75% WR)
  • Mitigation: Run anti-Jett comp with KAY/O suppress
  • Confidence: 89% | Impact: 85%

Default Compositions
────────────────────
🔮 EXPECT: Jett, Sova, KAY/O, Omen, Viper
  • Used in 45% of recent games (2.5x global avg)
  • Win rate with this comp: 68%
  • Key player: Player312 on Jett (1.17 K/D)
  • Counter: Ban Jett or run double duelist to match aggression

╔═══════════════════════════════════════════════════════════╗
║  MID-GAME ANALYSIS (In-Round Execution)                  ║
╚═══════════════════════════════════════════════════════════╝

Objective Control
─────────────────
⚔️ EXPLOIT post-plant weakness
  • Spike plant conversion: 21% (vs 50% baseline)
  • Evidence:
    - 384 plants, only 81 explosions
    - High defuse rate by opponents (112 defuses)
    - Weak post-plant positioning
  • Action: Apply aggressive post-plant pressure
  • Drill: "Post-Plant Defense" (15 min practice)
  • Confidence: 92% | Impact: 78%

Economy Patterns
────────────────
💰 FORCE eco rounds
  • Avg money: $8,596 (conservative)
  • Force buy rate: Low (saves often)
  • Action: Force eco rounds to snowball advantage
  • Counter-Risk: They may surprise with force buy
  • Confidence: 76% | Impact: 65%

╔═══════════════════════════════════════════════════════════╗
║  MICRO ANALYSIS (Player Targeting)                       ║
╚═══════════════════════════════════════════════════════════╝

Star Player
───────────
⚠️ WATCH Player312
  • K/D: 1.17 (highest on team)
  • Kills/game: 15.14 (high impact)
  • First blood rate: 10.2%
  • Agents: Primarily Jett (duelist)
  • Action: Prioritize utility to shut down early
  • Confidence: 94% | Impact: 88%

Weak Link
─────────
🎯 TARGET mada
  • K/D: Declining trend (1.05 → 0.89 in 2 weeks)
  • First death impact: 85% team loss rate
  • Zero-kill deaths: 56% of rounds
  • Action: Exploit poor entry protocol, force 1v1s
  • Drill: "Anti-Entry Practice" (10 min)
  • Confidence: 87% | Impact: 91%
```

---

### **Layer 3: ANALYST APPENDIX (60 minutes)**

**Purpose:** Deep analysis for post-match review or scout validation

**Content:**
- Full raw statistics tables
- Charts and visualizations
- Sample sizes and confidence intervals
- Derivation methodology
- Match history references
- Edge case caveats

**Format:**
```
┌─────────────────────────────────────────────────────────┐
│  📈 DETAILED STATISTICS & METHODOLOGY                    │
└─────────────────────────────────────────────────────────┘

Map Performance (Full Breakdown)
─────────────────────────────────
| Map     | Games | Wins | Losses | WR    | Attack WR | Defense WR |
|---------|-------|------|--------|-------|-----------|------------|
| Ascent  | 12    | 9    | 3      | 75%   | 70%       | 80%        |
| Bind    | 10    | 7    | 3      | 70%   | 65%       | 75%        |
| Icebox  | 15    | 4    | 11     | 27%   | 20%       | 33%        |
| Haven   | 8     | 5    | 3      | 63%   | 60%       | 67%        |
| Split   | 4     | 2    | 2      | 50%   | 45%       | 55%        |

Player Statistics (Detailed)
─────────────────────────────
| Player    | Games | K/D  | Kills/G | Deaths/G | FB%  | Trend      |
|-----------|-------|------|---------|----------|------|------------|
| Player312 | 49    | 1.17 | 15.14   | 12.94    | 10%  | Stable     |
| mada      | 49    | 0.89 | 13.82   | 15.53    | 8%   | Declining  |
| Player297 | 49    | 0.96 | 14.06   | 14.63    | 9%   | Volatile   |

Match History (Recent 10 Games)
────────────────────────────────
1. vs Sentinels (Ascent) - WON 13-8
2. vs G2 Esports (Bind) - WON 13-11
3. vs Team Liquid (Icebox) - LOST 8-13
4. vs FNATIC (Haven) - WON 13-10
5. vs Cloud9 (Ascent) - WON 13-6
...

Methodology Notes
─────────────────
• Data source: GRID API (Stats Feed + Series State)
• Time window: Last 6 months (49 games analyzed)
• Confidence intervals: 95% (Wilson score)
• Sample size minimum: 5 games for inclusion
• Trend calculation: Exponential moving average (α=0.3)
• Velocity: Linear regression over last 14 days
```

---

## **TECHNOLOGY STACK** {#technology-stack}

### **Backend (Python)**
- **Python 3.11+**
- **Pandas** - Data aggregation and analysis
- **Pydantic** - Data validation and models
- **PydanticAI** - LLM-powered routing (Gemini integration)
- **psycopg2-binary** - PostgreSQL driver
- **Google GenAI SDK** (`google-genai`) - Gemini API client

### **Backend (Java)**
- **Java 17+**
- **Spring Boot 3.x** - REST API
- **Spring Data JPA** - Database ORM
- **PostgreSQL JDBC** - Database driver

### **Database**
- **PostgreSQL 15+**
- **JSONB columns** - Flexible report storage
- **Connection pooling** - Performance optimization

### **Frontend**
- **React 18+**
- **Next.js 14+** (optional, for SSR)
- **Tailwind CSS** - Styling

### **Data Source**
- **GRID API** - Official esports data (VALORANT)
    - Stats Feed API (pre-aggregated statistics)
    - Series State API (match details)
    - Central Data Feed (team/player lookup)

### **Infrastructure**
- **Docker** - Containerization
- **Docker Compose** - Multi-service orchestration

---

## **CURRENT STATE & WHAT WE'RE BUILDING** {#current-state}

### **✅ What Already Works (70% Complete)**

**1. Ingestion Layer (100% Done)**
- ✅ `fetch_teams.py` - Resolves team names to IDs
- ✅ `fetch_stats.py` - Gets team/player statistics
- ✅ `fetch_series.py` - Gets match history
- ✅ `fetch_match_details.py` - Gets composition data
- **All functions return normalized dictionaries ready for analysis**

**2. Database Schema (100% Done)**
- ✅ `report_requests` table (job queue)
- ✅ `scouting_reports` table (results storage)
- ✅ Connection pooling configured
- ✅ Migrations system in place

**3. Job Processing System (90% Done)**
- ✅ `report_generator.py` - Polls and processes jobs
- ✅ `prompt_router.py` - LLM-powered routing
- ⚠️ Handler functions exist but need enhancement

**4. Transform Layer (60% Done)**
- ✅ `team_analysis.py` - Basic win rates, side balance
- ✅ `player_analysis.py` - K/D, star player detection
- ✅ `map_analysis.py` - Map win rates
- ⚠️ Needs: velocity, counter-risk, drill generation

**5. Insight Generator (40% Done)**
- ✅ Basic insight aggregation
- ⚠️ No priority scoring
- ⚠️ No structured Insight Objects
- ⚠️ Plain text output (needs 3-layer structure)

---

### **🚧 What We're Building in 10 Days (30% Remaining)**

**1. Core Infrastructure (Days 1-3)**
- **Insight Object Model** - The structured data class
- **Priority Scoring System** - impact × confidence × freshness × sample_quality
- **Report Renderer** - 3-layer output (Flash Card → Tactical → Appendix)

**2. Temporal Layer (Days 2-4)**
- **Velocity Engine** - Calculate trend, velocity, forecast
- **Trend Analyzer** - Detect declining/stable/rising patterns
- **Freshness Calculator** - Weight recent data higher

**3. Risk & Actionability (Days 3-6)**
- **Counter-Risk Modeler** - "If you do X, they'll respond with Y"
- **Mitigation Generator** - "Here's how to handle Y"
- **Drill Prescription Generator** - Turn insights into practice routines

**4. Meta & Polish (Days 5-8)**
- **Global Meta Analyzer** - Compare team stats to global averages
- **Visual Formatter** - Icons, emojis, markdown styling
- **PDF Export** - Professional report export (optional)

**5. Integration & Testing (Days 7-10)**
- **End-to-end testing** - Full flow from prompt to report
- **Performance optimization** - Sub-30 second report generation
- **Bug fixes and polish**

---

## **KEY ARCHITECTURAL DECISIONS** {#architectural-decisions}

### **1. Why LLM Routing Instead of Rule-Based?**

**Problem:** With 12+ analysis types, rule-based routing becomes fragile.

**Old approach:**
```python
if "scouting report" in prompt and "team" in prompt:
    return handle_full_report(extract_team_name(prompt))
elif "map" in prompt:
    return handle_map_analysis(extract_team(prompt), extract_map(prompt))
# ... 50+ if/elif statements
```

**New approach (LLM-powered):**
```python
router = GeneralPromptRouter()
result = await router.resolve_user_prompt("How does Team Liquid perform on Ascent?")
# LLM automatically picks MapAnalysisTool and extracts params
```

**Benefits:**
- ✅ Handles ambiguous prompts ("Scout Liquid" vs "Generate report for Liquid")
- ✅ Extracts parameters automatically (team names, time windows, map names)
- ✅ Extensible - add new tools without changing routing logic
- ✅ Natural language UI - no complex forms needed

---

### **2. Why Database as Contract (Not Microservices)?**

**Problem:** Java and Python need to communicate reliably.

**Alternative rejected:** HTTP calls between services
```
Java API → POST http://python-worker/generate-report → Python Worker
```

</artifact>